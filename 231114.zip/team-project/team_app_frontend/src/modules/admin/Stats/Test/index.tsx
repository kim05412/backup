// StatsView.tsx
import { useState, useEffect } from "react";
import axios from "axios";
import { BASE_URL } from "../../book/Book";

type Stats = {
  ageGroup: string;
  gender: string;
  title: string;
  publisher: string;
  categoryName: string;
  author: string;
  hitsCount: number;
};

const StatsView = () => {
  const [stats, setStats] = useState<Stats[]>([]);

  useEffect(() => {
    // 서버에서 통계 데이터를 가져오는 함수
    const fetchStats = async () => {
      const response = await axios.get(`${BASE_URL}/stats`);
      setStats(response.data);
    };

    fetchStats();
  }, []);

  return (
    <div>
      <h1>Statistics</h1>
      <table>
        {/* 테이블 헤더 */}
        <thead>
          <tr>
            <th>Age Group</th>
            <th>Gender</th>
            <th>Title</th>
            <th>Publisher</th>
            <th>Category Name</th>
            <th>Author</th>
            <th>Hits Count</th>
          </tr>
        </thead>
        {/* 테이블 바디 */}
        <tbody>
          {stats.map((stat, index) => (
            <tr key={index}>
              <td>{stat.ageGroup}</td>
              <td>{stat.gender}</td>
              <td>{stat.title}</td>
              <td>{stat.publisher}</td>
              <td>{stat.categoryName}</td>
              <td>{stat.author}</td>
              <td>{stat.hitsCount}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default StatsView;
