package com.example.app_backend.sales

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SalesApplicationTests {

	@Test
	fun contextLoads() {
	}

}
