package com.example.app_backend.admin.hits

data class HourlyHitDto(
    val hour: String,
    val hits: Long
)