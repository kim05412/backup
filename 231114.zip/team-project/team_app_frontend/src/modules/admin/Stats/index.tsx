import { useState, useEffect } from "react";
import axios from "axios";

// 중첩) 서버로부터 받을 데이터의 타입을 정의
// interface BookViewsByAgeGroup {
//   [publisher: string]: {
//     [author: string]: {
//       [categoryName: string]: number;
//     };
//   };
// }
interface BookViewsStats {
  ageGroup: string;
  gender: string;
  publisher: string;
  author: string;
  categoryName: string;
  views: number;
}

// API 응답 형식이 배열이라고 가정하고 인터페이스를 사용합니다.
type BookViewsStatsResponse = BookViewsStats[];

// 컴포넌트 함수 정의
const BookStatsTable: React.FC = () => {
  const [data, setData] = useState<BookViewsStatsResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get<BookViewsStatsResponse>("/api/path-to-your-endpoint");
        setData(response.data);
        setLoading(false);
      } catch (error: any) {
        setError(error.message);
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;

  // 데이터를 테이블로 렌더링합니다.
  return (
    <table>
      <thead>
        <tr>
          <th>Age Group</th>
          <th>Gender</th>
          <th>Publisher</th>
          <th>Author</th>
          <th>Category Name</th>
          <th>Views</th>
        </tr>
      </thead>
      <tbody>
        {data?.map((stat, index) => (
          <tr key={index}>
            <td>{stat.ageGroup}</td>
            <td>{stat.gender}</td>
            <td>{stat.publisher}</td>
            <td>{stat.author}</td>
            <td>{stat.categoryName}</td>
            <td>{stat.views}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default BookStatsTable;
