// import axios from "axios";
// import { BASE_URL } from "../Book";

// const BookDelete = ({ onDeleteBook }) => {
//   const deleteBookData = async (itemId) => {
//     try {
//       const response = await axios.delete(`${BASE_URL}/${itemId}`);
//       return response.data;
//     } catch (error) {
//       console.error("책을 삭제하는 중에 오류가 발생했습니다", error);
//       throw error;
//     }
//   };
// };
